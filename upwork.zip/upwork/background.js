// Upwork Talent Scraper - Background Service Worker
// Google searches agency names, finds websites, extracts social links - all via fetch

console.log('[Upwork Scraper] Background service worker loaded');

// ── Social media regex patterns ──────────────────────────────────────
const SOCIAL_PATTERNS = {
  linkedin:  /https?:\/\/(?:www\.)?linkedin\.com\/(?:company|in|school)\/[a-zA-Z0-9_-]+/gi,
  instagram: /https?:\/\/(?:www\.)?instagram\.com\/[a-zA-Z0-9_.]+/gi,
  facebook:  /https?:\/\/(?:www\.)?facebook\.com\/[a-zA-Z0-9_.]+/gi,
  twitter:   /https?:\/\/(?:www\.)?(?:twitter\.com|x\.com)\/[a-zA-Z0-9_]+/gi,
  youtube:   /https?:\/\/(?:www\.)?youtube\.com\/(?:channel|c|@|user)\/[a-zA-Z0-9_-]+/gi,
  github:    /https?:\/\/(?:www\.)?github\.com\/[a-zA-Z0-9_-]+/gi,
  dribbble:  /https?:\/\/(?:www\.)?dribbble\.com\/[a-zA-Z0-9_-]+/gi,
  behance:   /https?:\/\/(?:www\.)?behance\.net\/[a-zA-Z0-9_-]+/gi,
};

// URLs to exclude (share buttons, SDKs, generic pages)
const SOCIAL_EXCLUSIONS = [
  'intent/', 'sharer/', 'share?', 'share/', '/plugins/', '/oauth',
  'platform.twitter', 'connect.facebook', 'apis.google',
  '/login', '/signup', '/register', '/help', '/about', '/legal',
  '/privacy', '/terms', '/policy'
];

// ── Fetch a page with browser-like headers ───────────────────────────
async function fetchPage(url, timeoutMs = 12000) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'identity',
        'Cache-Control': 'no-cache',
      },
      redirect: 'follow',
    });

    clearTimeout(timeoutId);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return await response.text();
  } catch (e) {
    clearTimeout(timeoutId);
    throw e;
  }
}

// ── Google search and get first result URL ───────────────────────────
async function googleSearchForWebsite(agencyName) {
  const query = encodeURIComponent(agencyName);
  const searchUrl = `https://www.google.com/search?q=${query}&num=5&hl=en`;

  console.log(`[Google] Searching: ${agencyName}`);

  try {
    const html = await fetchPage(searchUrl);

    // Google puts result URLs in several formats:
    // 1. /url?q=https://example.com/&sa=...
    // 2. data-href="https://example.com"
    // 3. <a href="https://example.com" ...>

    const urls = [];

    // Pattern 1: /url?q= redirects (most common in fetch results)
    const redirectPattern = /\/url\?q=(https?:\/\/[^&"]+)/gi;
    let match;
    while ((match = redirectPattern.exec(html)) !== null) {
      const url = decodeURIComponent(match[1]);
      urls.push(url);
    }

    // Pattern 2: Direct href links in result cards
    const hrefPattern = /href="(https?:\/\/(?!www\.google\.|google\.com|gstatic\.com|googleapis\.com|youtube\.com\/results|accounts\.google|webcache\.google|translate\.google|maps\.google|play\.google|support\.google|policies\.google|schema\.org)[^"]+)"/gi;
    while ((match = hrefPattern.exec(html)) !== null) {
      urls.push(match[1]);
    }

    // Pattern 3: data-href attributes
    const dataHrefPattern = /data-href="(https?:\/\/[^"]+)"/gi;
    while ((match = dataHrefPattern.exec(html)) !== null) {
      urls.push(match[1]);
    }

    // Filter out unwanted domains
    const skipDomains = [
      'google.com', 'google.co', 'gstatic.com', 'googleapis.com',
      'youtube.com', 'facebook.com', 'twitter.com', 'x.com',
      'linkedin.com', 'instagram.com', 'pinterest.com', 'tiktok.com',
      'github.com', 'behance.net', 'dribbble.com',
      'upwork.com', 'wikipedia.org', 'yelp.com',
      'glassdoor.com', 'indeed.com', 'crunchbase.com',
      'bloomberg.com', 'reddit.com', 'quora.com',
      'amazon.com', 'apple.com', 'microsoft.com',
      'w3.org', 'schema.org', 'cloudflare.com'
    ];

    const filteredUrls = urls.filter(url => {
      try {
        const hostname = new URL(url).hostname.toLowerCase();
        return !skipDomains.some(d => hostname.includes(d));
      } catch {
        return false;
      }
    });

    // Deduplicate by domain
    const seen = new Set();
    const uniqueUrls = [];
    for (const url of filteredUrls) {
      try {
        const domain = new URL(url).hostname;
        if (!seen.has(domain)) {
          seen.add(domain);
          uniqueUrls.push(url);
        }
      } catch {
        // skip
      }
    }

    if (uniqueUrls.length > 0) {
      // Return just the origin (root domain)
      try {
        const firstUrl = new URL(uniqueUrls[0]);
        const website = firstUrl.origin;
        console.log(`[Google] Found website: ${website}`);
        return website;
      } catch {
        return uniqueUrls[0];
      }
    }

    console.log(`[Google] No website found for: ${agencyName}`);
    return '';

  } catch (e) {
    console.warn(`[Google] Search failed for "${agencyName}":`, e.message);
    return '';
  }
}

// ── Extract social links from website HTML ───────────────────────────
function extractSocialLinks(html) {
  const socials = {};

  // Focus on footer area — typically the last 40% of HTML
  const footerStart = Math.floor(html.length * 0.55);
  const footerHtml = html.substring(footerStart);

  for (const [name, regex] of Object.entries(SOCIAL_PATTERNS)) {
    // Try footer first
    regex.lastIndex = 0;
    let match = regex.exec(footerHtml);

    // Then full page
    if (!match) {
      regex.lastIndex = 0;
      match = regex.exec(html);
    }

    if (match) {
      const url = match[0];
      // Skip excluded patterns
      if (!SOCIAL_EXCLUSIONS.some(ex => url.includes(ex))) {
        // Clean the URL
        socials[name] = url.replace(/[#?].*$/, '').replace(/\/+$/, '');
      }
    }
  }

  return socials;
}

// ── Enrich a single agency ───────────────────────────────────────────
async function enrichAgency(agencyName) {
  const result = { website: '', socials: {} };

  if (!agencyName) return result;

  try {
    // Step 1: Google the agency name to find their website
    result.website = await googleSearchForWebsite(agencyName);

    // Step 2: Fetch the website and extract social links from footer
    if (result.website) {
      try {
        console.log(`[Enrichment] Fetching website: ${result.website}`);
        const siteHtml = await fetchPage(result.website);

        if (siteHtml && siteHtml.length > 200) {
          result.socials = extractSocialLinks(siteHtml);
          const foundSocials = Object.keys(result.socials).filter(k => result.socials[k]);
          console.log(`[Enrichment] ${agencyName}: Found ${foundSocials.length} socials: ${foundSocials.join(', ')}`);
        }
      } catch (e) {
        console.warn(`[Enrichment] Could not fetch ${result.website}:`, e.message);
      }
    }

  } catch (e) {
    console.warn(`[Enrichment] Error enriching ${agencyName}:`, e.message);
  }

  return result;
}

// ── Message Listener ─────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'enrichAgency') {
    enrichAgency(request.agencyName)
      .then(result => sendResponse(result))
      .catch(e => {
        console.error('[Enrichment] Fatal error:', e);
        sendResponse({ website: '', socials: {}, error: e.message });
      });
    return true; // Keep message channel open for async
  }

  if (request.action === 'fetchDashboard') {
    fetch(request.url, request.options)
      .then(async res => {
        const isJson = res.headers.get('content-type')?.includes('application/json');
        const data = isJson ? await res.json() : await res.text();
        if (!res.ok) {
          sendResponse({ error: typeof data === 'string' ? data : (data.error || `HTTP ${res.status}`) });
        } else {
          sendResponse({ data });
        }
      })
      .catch(err => {
        sendResponse({ error: err.message });
      });
    return true; // Keep channel open for async
  }
});
