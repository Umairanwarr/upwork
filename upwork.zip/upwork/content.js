// Upwork Talent Scraper - Content Script
// Runs on: https://www.upwork.com/nx/search/talent/*

(function () {
  'use strict';

  let scrapedData = [];
  let isScrapingInProgress = false;
  let isEnrichmentInProgress = false;

  // ── Communication Bridge with Dashboard ─────────────────────────────
  async function sendToBackend(url, options = {}) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { action: 'fetchDashboard', url, options },
        response => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else if (response && response.error) {
            reject(new Error(response.error));
          } else {
            resolve(response ? response.data : null);
          }
        }
      );
    });
  }

  // ── Inject Floating Panel ──────────────────────────────────────────
  function createFloatingPanel() {
    if (document.getElementById('uw-scraper-panel')) return;

    const panel = document.createElement('div');
    panel.id = 'uw-scraper-panel';
    panel.innerHTML = `
      <div class="uw-scraper-header">
        <div class="uw-scraper-logo">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
            <polyline points="14 2 14 8 20 8"/>
            <line x1="16" y1="13" x2="8" y2="13"/>
            <line x1="16" y1="17" x2="8" y2="17"/>
            <polyline points="10 9 9 9 8 9"/>
          </svg>
          <span>Upwork Scraper</span>
        </div>
        <button id="uw-scraper-minimize" title="Minimize">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="5" y1="12" x2="19" y2="12"/>
          </svg>
        </button>
      </div>
      <div class="uw-scraper-body">
        <div class="uw-scraper-stats">
          <div class="uw-stat">
            <span class="uw-stat-value" id="uw-count-current">0</span>
            <span class="uw-stat-label">This Page</span>
          </div>
          <div class="uw-stat">
            <span class="uw-stat-value" id="uw-count-total">0</span>
            <span class="uw-stat-label">Total Collected</span>
          </div>
        </div>
        <div class="uw-scraper-actions">
          <button id="uw-btn-scrape" class="uw-btn uw-btn-primary">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="11" cy="11" r="8"/>
              <line x1="21" y1="21" x2="16.65" y2="16.65"/>
            </svg>
            Scrape This Page
          </button>
          <button id="uw-btn-scrape-all" class="uw-btn uw-btn-secondary">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="2" y="2" width="20" height="20" rx="2"/>
              <path d="M8 6h8M8 10h8M8 14h5"/>
            </svg>
            Scrape All Pages
          </button>
          <button id="uw-btn-enrich" class="uw-btn uw-btn-enrich" disabled>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="10"/>
              <line x1="2" y1="12" x2="22" y2="12"/>
              <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
            </svg>
            Enrich Social Links
          </button>
          <button id="uw-btn-export" class="uw-btn uw-btn-success" disabled>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
              <polyline points="7 10 12 15 17 10"/>
              <line x1="12" y1="15" x2="12" y2="3"/>
            </svg>
            Export to Excel
          </button>
          <button id="uw-btn-send-dashboard" class="uw-btn uw-btn-primary" disabled style="background:#4f46e5; border-color:#4338ca;">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M22 2L11 13M22 2l-7 20-4-9-9-4z"/>
            </svg>
            Send to Dashboard
          </button>
          <button id="uw-btn-clear" class="uw-btn uw-btn-danger" disabled>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="3 6 5 6 21 6"/>
              <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
            </svg>
            Clear Data
          </button>
          <div id="uw-enrich-progress" class="uw-enrich-progress" style="display:none;">
            <div class="uw-progress-bar">
              <div class="uw-progress-fill" id="uw-progress-fill"></div>
            </div>
            <div class="uw-progress-text" id="uw-progress-text">Enriching...</div>
          </div>
        </div>
        <!-- Automation Panel -->
        <div id="uw-automation-panel" style="display: none; flex-direction: column; gap: 12px; padding: 12px; background: rgba(79, 70, 229, 0.08); border: 1px solid rgba(79, 70, 229, 0.3); border-radius: 6px; margin: 8px;">
          <div id="uw-auto-title" style="font-weight: 700; color: #4f46e5; display: flex; align-items: center; gap: 6px; font-size: 13px;">
            <span class="status-dot" style="background: #4f46e5; animation: pulse 1s ease-in-out infinite; width: 7px; height: 7px; border-radius: 50%;"></span>
            Dashboard Automation Active
          </div>
          <div id="uw-auto-status-text" style="font-size: 12px; color: var(--text-2); line-height: 1.4; word-break: break-word;">
            Waiting for dashboard...
          </div>
          <button id="uw-btn-abort-auto" class="uw-btn uw-btn-danger" style="width: 100%; justify-content: center; height: 32px; font-size: 12px;">
            Abort Scraper
          </button>
        </div>
        <div id="uw-scraper-status" class="uw-scraper-status"></div>
        <div id="uw-scraper-preview" class="uw-scraper-preview"></div>
      </div>
    `;

    document.body.appendChild(panel);

    // Make panel draggable
    makeDraggable(panel);

    // Event listeners
    document.getElementById('uw-scraper-minimize').addEventListener('click', toggleMinimize);
    document.getElementById('uw-btn-scrape').addEventListener('click', scrapeCurrentPage);
    document.getElementById('uw-btn-scrape-all').addEventListener('click', scrapeAllPages);
    document.getElementById('uw-btn-enrich').addEventListener('click', enrichData);
    document.getElementById('uw-btn-export').addEventListener('click', exportToExcel);
    document.getElementById('uw-btn-clear').addEventListener('click', clearData);
    document.getElementById('uw-btn-send-dashboard').addEventListener('click', sendToDashboard);
    document.getElementById('uw-btn-abort-auto').addEventListener('click', abortAutomation);
  }

  // ── Draggable Panel ────────────────────────────────────────────────
  function makeDraggable(el) {
    const header = el.querySelector('.uw-scraper-header');
    let isDragging = false;
    let startX, startY, initialX, initialY;

    header.addEventListener('mousedown', (e) => {
      if (e.target.closest('button')) return;
      isDragging = true;
      startX = e.clientX;
      startY = e.clientY;
      const rect = el.getBoundingClientRect();
      initialX = rect.left;
      initialY = rect.top;
      el.style.transition = 'none';
    });

    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      el.style.left = (initialX + dx) + 'px';
      el.style.top = (initialY + dy) + 'px';
      el.style.right = 'auto';
    });

    document.addEventListener('mouseup', () => {
      isDragging = false;
      el.style.transition = '';
    });
  }

  // ── Minimize/Maximize ──────────────────────────────────────────────
  function toggleMinimize() {
    const panel = document.getElementById('uw-scraper-panel');
    panel.classList.toggle('uw-minimized');
  }

  // ── Status Message ─────────────────────────────────────────────────
  function setStatus(message, type = 'info') {
    const status = document.getElementById('uw-scraper-status');
    status.textContent = message;
    status.className = 'uw-scraper-status uw-status-' + type;
    if (type === 'success' || type === 'info') {
      setTimeout(() => {
        status.textContent = '';
        status.className = 'uw-scraper-status';
      }, 5000);
    }
  }

  // ── Scrape Current Page ────────────────────────────────────────────
  function scrapeCurrentPage() {
    const results = extractDataFromPage();
    if (results.length === 0) {
      setStatus('No talent cards found on this page.', 'warning');
      return;
    }

    // Add results, avoiding duplicates by profile URL
    const existingUrls = new Set(scrapedData.map(d => d.profileUrl));
    let newCount = 0;
    results.forEach(r => {
      if (!existingUrls.has(r.profileUrl)) {
        scrapedData.push(r);
        existingUrls.add(r.profileUrl);
        newCount++;
      }
    });

    updateUI();
    setStatus(`Scraped ${newCount} new profiles (${results.length - newCount} duplicates skipped)`, 'success');
    highlightScrapedCards();
  }

  // ── Extract Data From Page ─────────────────────────────────────────
  function extractDataFromPage() {
    const results = [];

    // Find all freelancer profile links on the page
    // Each profile link = one talent card
    const profileLinks = document.querySelectorAll('a[data-test="UpLink"].profile-link, a.profile-link[href*="/freelancers/"]');

    // Dedupe by href to avoid double-counting
    const seenHrefs = new Set();
    const uniqueLinks = [];
    profileLinks.forEach(link => {
      const href = link.getAttribute('href');
      if (href && !seenHrefs.has(href)) {
        seenHrefs.add(href);
        uniqueLinks.push(link);
      }
    });

    console.log(`[Upwork Scraper] Found ${uniqueLinks.length} profile links on page`);

    uniqueLinks.forEach(profileLink => {
      try {
        // Walk up from the profile link to find the containing card
        const card = findParentCard(profileLink);
        if (!card) {
          console.warn('[Upwork Scraper] Could not find parent card for:', profileLink.textContent.trim());
          return;
        }

        const data = extractCardData(card, profileLink);
        if (data && data.name) {
          results.push(data);
          console.log(`[Upwork Scraper] Extracted: ${data.name} | Agency: ${data.agencyName || 'N/A'}`);
        }
      } catch (e) {
        console.warn('[Upwork Scraper] Error parsing card:', e);
      }
    });

    document.getElementById('uw-count-current').textContent = results.length;
    return results;
  }

  // ── Find Parent Card Container ─────────────────────────────────────
  function findParentCard(profileLink) {
    let el = profileLink;
    for (let i = 0; i < 15; i++) {
      el = el.parentElement;
      if (!el || el === document.body) return null;

      // Look for common card containers
      if (
        el.classList.contains('up-card-section') ||
        el.classList.contains('freelancer-tile') ||
        el.getAttribute('data-test') === 'freelancer-card' ||
        el.getAttribute('data-test') === 'FreelancerCard' ||
        // Check if this element contains both the profile link AND the agency section
        (el.querySelector && el.querySelector('[data-test="FreelancerTileAgency"]') && el.querySelector('a.profile-link'))
      ) {
        return el;
      }
    }

    // Fallback: walk up ~8 levels from the profile link
    el = profileLink;
    for (let i = 0; i < 8; i++) {
      if (el.parentElement && el.parentElement !== document.body) {
        el = el.parentElement;
      }
    }
    return el;
  }

  // ── Extract Data From a Single Card ────────────────────────────────
  function extractCardData(card, profileLink) {
    const data = {
      name: '',
      title: '',
      profileUrl: '',
      agencyName: '',
      agencyUrl: ''
    };

    // ─ Name (from the profile link text) ─
    // The name is the text content of: <a data-test="UpLink" class="profile-link">Name</a>
    if (profileLink) {
      data.name = profileLink.textContent.trim();
    }

    // Fallback name selectors
    if (!data.name) {
      const nameSelectors = [
        'a[data-test="UpLink"]',
        'a.profile-link',
        'a[href*="/freelancers/"]'
      ];
      for (const sel of nameSelectors) {
        const el = card.querySelector(sel);
        if (el && el.textContent.trim()) {
          data.name = el.textContent.trim();
          break;
        }
      }
    }

    // ─ Profile URL ─
    const linkEl = profileLink || card.querySelector('a[data-test="UpLink"], a.profile-link, a[href*="/freelancers/"]');
    if (linkEl) {
      const href = linkEl.getAttribute('href');
      if (href) {
        // Clean the URL - remove referrer params for cleaner output
        const cleanHref = href.split('?')[0];
        data.profileUrl = cleanHref.startsWith('http')
          ? cleanHref
          : 'https://www.upwork.com' + cleanHref;
      }
    }

    // ─ Title / Headline ─
    const titleSelectors = [
      '[data-test="tile-title"]',
      '[data-test="FreelancerTileTitle"]',
      '.freelancer-tile-title',
      'h4'
    ];
    for (const sel of titleSelectors) {
      const el = card.querySelector(sel);
      if (el && el.textContent.trim() && el.textContent.trim() !== data.name) {
        data.title = el.textContent.trim();
        break;
      }
    }



    // ─ Agency ("Associated with") ─
    // Structure from actual Upwork HTML:
    // <div data-test="FreelancerTileAgency" class="freelancer-tile-agency">
    //   <div>Associated with</div>
    //   <div class="name">TetaLab</div>
    //   <img data-test="FreelancerTileAgencyLogoVue" src="...org-logo/ID..." alt="AgencyName">
    // </div>

    // Method 1: Direct selector for agency container
    const agencyContainer = card.querySelector('[data-test="FreelancerTileAgency"], .freelancer-tile-agency');
    if (agencyContainer) {
      // Get agency name from the .name div or .rr-mask div
      const agencyNameEl = agencyContainer.querySelector('.name, .rr-mask');
      if (agencyNameEl) {
        data.agencyName = agencyNameEl.textContent.trim();
      }

      // Try to get agency URL from a link inside the container
      const agencyLink = agencyContainer.querySelector('a[href*="/ag"], a[href*="/agencies/"]');
      if (agencyLink) {
        data.agencyUrl = agencyLink.href.startsWith('http')
          ? agencyLink.href
          : 'https://www.upwork.com' + agencyLink.getAttribute('href');
      }

      // If no direct link, try to construct URL from logo
      if (!data.agencyUrl) {
        const agencyLogo = agencyContainer.querySelector(
          'img[data-test="FreelancerTileAgencyLogoVue"], img.air3-avatar-company'
        );
        if (agencyLogo) {
          // Alt text often has the agency name
          if (!data.agencyName && agencyLogo.alt) {
            data.agencyName = agencyLogo.alt;
          }
          // Logo src like: https://assets.static-upwork.com/org-logo/1017072460223688704
          // The org ID can help construct the agency URL
          const logoSrc = agencyLogo.getAttribute('src') || '';
          const orgIdMatch = logoSrc.match(/org-logo\/(\d+)/);
          if (orgIdMatch) {
            data.agencyUrl = 'https://www.upwork.com/agencies/' + orgIdMatch[1] + '/';
          }
        }
      }

      // Fallback: if still no name, look for any clickable agency element
      if (!data.agencyName) {
        const anyLink = agencyContainer.querySelector('a');
        if (anyLink && anyLink.textContent.trim()) {
          data.agencyName = anyLink.textContent.trim();
          if (anyLink.href) {
            data.agencyUrl = anyLink.href;
          }
        }
      }
    }

    // Method 2: If agency container not found, search for "Associated with" text
    if (!data.agencyName) {
      const allDivs = card.querySelectorAll('div');
      for (const div of allDivs) {
        // Check only leaf-ish divs that contain "Associated with"
        if (div.childElementCount <= 5 && div.textContent.includes('Associated with')) {
          // The agency name is in a sibling or child .name div
          const nameDiv = div.querySelector('.name') || div.querySelector('.rr-mask');
          if (nameDiv) {
            data.agencyName = nameDiv.textContent.trim();
          } else {
            // Try the next sibling div
            const nextDiv = div.nextElementSibling;
            if (nextDiv && nextDiv.classList.contains('name')) {
              data.agencyName = nextDiv.textContent.trim();
            }
          }

          // Try to find a link nearby for agency URL
          const nearbyLink = div.querySelector('a') ||
            div.parentElement?.querySelector('a[href*="/ag"]') ||
            div.parentElement?.querySelector('a[href*="/agencies"]');
          if (nearbyLink) {
            data.agencyUrl = nearbyLink.href;
            if (!data.agencyName) {
              data.agencyName = nearbyLink.textContent.trim();
            }
          }

          // Try logo for URL
          if (!data.agencyUrl) {
            const parentContainer = div.closest('.freelancer-tile-agency') || div.parentElement;
            if (parentContainer) {
              const logo = parentContainer.querySelector('img[src*="org-logo"]');
              if (logo) {
                const orgMatch = logo.src.match(/org-logo\/(\d+)/);
                if (orgMatch) {
                  data.agencyUrl = 'https://www.upwork.com/agencies/' + orgMatch[1] + '/';
                }
                if (!data.agencyName && logo.alt) {
                  data.agencyName = logo.alt;
                }
              }
            }
          }
          break;
        }
      }
    }

    return data;
  }

  // ── Highlight Scraped Cards ────────────────────────────────────────
  function highlightScrapedCards() {
    const profileLinks = document.querySelectorAll('a[href*="/freelancers/"], a[href*="/fl/"]');
    const scrapedUrls = new Set(scrapedData.map(d => d.profileUrl));

    profileLinks.forEach(link => {
      if (scrapedUrls.has(link.href)) {
        let card = link;
        for (let i = 0; i < 8; i++) {
          card = card.parentElement;
          if (!card) break;
          if (card.classList.contains('up-card-section') || card.getAttribute('data-test')) {
            card.classList.add('uw-scraped-card');
            break;
          }
        }
      }
    });
  }

  // ── Scrape All Pages ───────────────────────────────────────────────
  async function scrapeAllPages() {
    if (isScrapingInProgress) {
      isScrapingInProgress = false;
      setStatus('Scraping stopped.', 'warning');
      document.getElementById('uw-btn-scrape-all').innerHTML = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <rect x="2" y="2" width="20" height="20" rx="2"/>
          <path d="M8 6h8M8 10h8M8 14h5"/>
        </svg>
        Scrape All Pages
      `;
      return;
    }

    isScrapingInProgress = true;
    document.getElementById('uw-btn-scrape-all').innerHTML = `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
      </svg>
      Stop Scraping
    `;

    let pageNum = 1;

    while (isScrapingInProgress) {
      setStatus(`Scraping page ${pageNum}...`, 'info');

      // Scrape current page
      scrapeCurrentPage();

      // Find and click next page button
      const nextButton = document.querySelector(
        'button[data-test="pagination-next"], ' +
        '.up-pagination-next, ' +
        'a[data-test="pagination-next"], ' +
        'button.pagination-next, ' +
        '[aria-label="Next"]'
      );

      // Also try finding the next page number link
      let nextPageLink = null;
      if (!nextButton || nextButton.disabled) {
        const pageLinks = document.querySelectorAll('.up-pagination a, [data-test="pagination"] a, nav[aria-label="Pagination"] a');
        const currentPage = document.querySelector('.up-pagination .is-active, [aria-current="page"], .pagination .active');
        if (currentPage) {
          nextPageLink = currentPage.nextElementSibling?.querySelector('a') || currentPage.nextElementSibling;
        }
      }

      const clickTarget = (nextButton && !nextButton.disabled) ? nextButton : nextPageLink;

      if (!clickTarget || clickTarget.disabled) {
        setStatus(`Scraping complete! Reached last page (${pageNum} pages scraped).`, 'success');
        break;
      }

      clickTarget.click();
      pageNum++;

      // Wait for page to load
      await new Promise(resolve => setTimeout(resolve, 3000));

      // Wait for content to update (watch for DOM changes)
      await waitForContentUpdate();
    }

    isScrapingInProgress = false;
    document.getElementById('uw-btn-scrape-all').innerHTML = `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <rect x="2" y="2" width="20" height="20" rx="2"/>
        <path d="M8 6h8M8 10h8M8 14h5"/>
      </svg>
      Scrape All Pages
    `;
    updateUI();
  }

  // ── Wait for Content Update ────────────────────────────────────────
  function waitForContentUpdate() {
    return new Promise(resolve => {
      const observer = new MutationObserver((mutations, obs) => {
        // Look for significant DOM changes indicating content load
        const significantChange = mutations.some(m =>
          m.addedNodes.length > 0 &&
          Array.from(m.addedNodes).some(n => n.nodeType === 1)
        );
        if (significantChange) {
          obs.disconnect();
          setTimeout(resolve, 1000); // Extra wait for rendering
        }
      });

      observer.observe(document.body, { childList: true, subtree: true });

      // Timeout fallback
      setTimeout(() => {
        observer.disconnect();
        resolve();
      }, 5000);
    });
  }

  // ── Update UI ──────────────────────────────────────────────────────
  function updateUI() {
    document.getElementById('uw-count-total').textContent = scrapedData.length;
    document.getElementById('uw-btn-export').disabled = scrapedData.length === 0;
    document.getElementById('uw-btn-enrich').disabled = scrapedData.length === 0;
    document.getElementById('uw-btn-clear').disabled = scrapedData.length === 0;
    const sendBtn = document.getElementById('uw-btn-send-dashboard');
    if (sendBtn) sendBtn.disabled = scrapedData.length === 0;
    updatePreview();
  }

  // ── Update Preview Table ───────────────────────────────────────────
  function updatePreview() {
    const preview = document.getElementById('uw-scraper-preview');
    if (scrapedData.length === 0) {
      preview.innerHTML = '';
      return;
    }

    const lastFive = scrapedData.slice(-5).reverse();
    let html = `
      <div class="uw-preview-header">
        <span>Latest entries (${scrapedData.length} total)</span>
      </div>
      <div class="uw-preview-table-wrapper">
        <table class="uw-preview-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Agency</th>
            </tr>
          </thead>
          <tbody>
    `;

    lastFive.forEach(d => {
      html += `
        <tr>
          <td>
            <a href="${d.profileUrl}" target="_blank" title="${d.name}">${d.name || 'N/A'}</a>
          </td>
          <td>
            ${d.agencyName
        ? `<a href="${d.agencyUrl}" target="_blank" title="${d.agencyName}">${d.agencyName}</a>`
        : '<span class="uw-na">N/A</span>'}
          </td>
        </tr>
      `;
    });

    html += `</tbody></table></div>`;
    preview.innerHTML = html;
  }

  // ── Enrich Data with Social Links ──────────────────────────────────
  async function enrichData() {
    if (scrapedData.length === 0) {
      setStatus('No data to enrich. Scrape first.', 'warning');
      return;
    }

    if (isEnrichmentInProgress) {
      isEnrichmentInProgress = false;
      setStatus('Enrichment stopped.', 'warning');
      document.getElementById('uw-btn-enrich').innerHTML = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="12" cy="12" r="10"/>
          <line x1="2" y1="12" x2="22" y2="12"/>
          <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
        </svg>
        Enrich Social Links
      `;
      return;
    }

    isEnrichmentInProgress = true;
    document.getElementById('uw-btn-enrich').innerHTML = `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
      </svg>
      Stop Enrichment
    `;

    const progressEl = document.getElementById('uw-enrich-progress');
    const progressFill = document.getElementById('uw-progress-fill');
    const progressText = document.getElementById('uw-progress-text');
    progressEl.style.display = 'block';

    // Collect unique agencies to avoid duplicate fetches
    const agencyMap = new Map();
    scrapedData.forEach((d, idx) => {
      if (d.agencyName && !d._enriched) {
        const key = d.agencyName;
        if (!agencyMap.has(key)) {
          agencyMap.set(key, { agencyUrl: d.agencyUrl, agencyName: d.agencyName, indices: [idx] });
        } else {
          agencyMap.get(key).indices.push(idx);
        }
      }
    });

    const agencies = Array.from(agencyMap.values());
    let completed = 0;
    const total = agencies.length;

    if (total === 0) {
      setStatus('All agencies already enriched or no agencies found.', 'info');
      progressEl.style.display = 'none';
      isEnrichmentInProgress = false;
      document.getElementById('uw-btn-enrich').innerHTML = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="12" cy="12" r="10"/>
          <line x1="2" y1="12" x2="22" y2="12"/>
          <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
        </svg>
        Enrich Social Links
      `;
      return;
    }

    setStatus(`Enriching ${total} unique agencies...`, 'info');

    for (const agency of agencies) {
      if (!isEnrichmentInProgress) break;

      completed++;
      const pct = Math.round((completed / total) * 100);
      progressFill.style.width = pct + '%';
      progressText.textContent = `${completed}/${total} — ${agency.agencyName}`;

      try {
        const result = await new Promise((resolve, reject) => {
          chrome.runtime.sendMessage(
            { action: 'enrichAgency', agencyUrl: agency.agencyUrl, agencyName: agency.agencyName },
            response => {
              if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
              } else {
                resolve(response || { website: '', socials: {} });
              }
            }
          );
        });

        // Apply results to all matching scraped entries
        agency.indices.forEach(idx => {
          scrapedData[idx].website = result.website || '';
          scrapedData[idx].linkedin = result.socials?.linkedin || '';
          scrapedData[idx].instagram = result.socials?.instagram || '';
          scrapedData[idx].facebook = result.socials?.facebook || '';
          scrapedData[idx].twitter = result.socials?.twitter || '';
          scrapedData[idx].youtube = result.socials?.youtube || '';
          scrapedData[idx].github = result.socials?.github || '';
          scrapedData[idx].dribbble = result.socials?.dribbble || '';
          scrapedData[idx].behance = result.socials?.behance || '';
          scrapedData[idx]._enriched = true;
        });

        console.log(`[Enrichment] ${agency.agencyName}: website=${result.website}, socials=${Object.keys(result.socials || {}).join(', ')}`);

      } catch (e) {
        console.warn(`[Enrichment] Failed for ${agency.agencyName}:`, e.message);
        agency.indices.forEach(idx => {
          scrapedData[idx]._enriched = true; // Mark as attempted
        });
      }

      // Small delay between requests to be polite
      await new Promise(r => setTimeout(r, 1500));
    }

    isEnrichmentInProgress = false;
    progressFill.style.width = '100%';
    progressText.textContent = 'Complete!';
    setTimeout(() => { progressEl.style.display = 'none'; }, 3000);

    document.getElementById('uw-btn-enrich').innerHTML = `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="12" cy="12" r="10"/>
        <line x1="2" y1="12" x2="22" y2="12"/>
        <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
      </svg>
      Enrich Social Links
    `;

    updateUI();
    setStatus(`Enrichment complete! Processed ${completed} agencies.`, 'success');
  }

  // ── Export to Excel (XLSX) ─────────────────────────────────────────
  function exportToExcel() {
    if (scrapedData.length === 0) {
      setStatus('No data to export.', 'warning');
      return;
    }

    // Build CSV content (compatible with Excel)
    const headers = [
      'Name', 'Title', 'Profile URL', 'Agency Name', 'Agency URL',
      'Website', 'LinkedIn', 'Instagram', 'Facebook', 'Twitter',
      'YouTube', 'GitHub', 'Dribbble', 'Behance'
    ];

    let csvContent = '\uFEFF'; // BOM for Excel UTF-8
    csvContent += headers.join(',') + '\n';

    scrapedData.forEach(d => {
      const row = [
        escapeCsv(d.name),
        escapeCsv(d.title),
        escapeCsv(d.profileUrl),
        escapeCsv(d.agencyName),
        escapeCsv(d.agencyUrl),
        escapeCsv(d.website),
        escapeCsv(d.linkedin),
        escapeCsv(d.instagram),
        escapeCsv(d.facebook),
        escapeCsv(d.twitter),
        escapeCsv(d.youtube),
        escapeCsv(d.github),
        escapeCsv(d.dribbble),
        escapeCsv(d.behance)
      ];
      csvContent += row.join(',') + '\n';
    });

    // Create and download
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const timestamp = new Date().toISOString().slice(0, 19).replace(/[T:]/g, '-');
    a.href = url;
    a.download = `upwork-talent-${timestamp}.csv`;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setStatus(`Exported ${scrapedData.length} profiles to CSV/Excel!`, 'success');
  }

  function escapeCsv(str) {
    if (!str) return '""';
    str = String(str);
    if (str.includes(',') || str.includes('"') || str.includes('\n')) {
      return '"' + str.replace(/"/g, '""') + '"';
    }
    return '"' + str + '"';
  }

  // ── Clear Data ─────────────────────────────────────────────────────
  function clearData() {
    if (confirm('Are you sure you want to clear all scraped data?')) {
      scrapedData = [];
      updateUI();
      setStatus('All data cleared.', 'info');

      // Remove highlights
      document.querySelectorAll('.uw-scraped-card').forEach(el => {
        el.classList.remove('uw-scraped-card');
      });
    }
  }

  // ── Send to Dashboard ──────────────────────────────────────────────
  async function sendToDashboard() {
    if (scrapedData.length === 0) return;
    setStatus('Sending leads to dashboard...', 'info');
    try {
      const res = await sendToBackend('https://upwork-one-mauve.vercel.app/api/outreach/import-json', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ leads: scrapedData })
      });
      if (res && res.ok) {
        setStatus(`Sent ${scrapedData.length} leads to Dashboard!`, 'success');
      } else {
        throw new Error((res && res.error) || 'Server rejected request');
      }
    } catch (e) {
      console.error('[Dashboard Link] Failed to send:', e);
      setStatus('Could not connect to Dashboard. Make sure upwork-one-mauve.vercel.app is reachable.', 'error');
    }
  }

  // ── Listen for messages from popup ─────────────────────────────────
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'getStatus') {
      sendResponse({
        count: scrapedData.length,
        isOnSearchPage: window.location.href.includes('/search/talent')
      });
    } else if (request.action === 'scrape') {
      scrapeCurrentPage();
      sendResponse({ count: scrapedData.length });
    } else if (request.action === 'export') {
      exportToExcel();
      sendResponse({ success: true });
    } else if (request.action === 'getData') {
      sendResponse({ data: scrapedData });
    }
    return true;
  });

  // ── Automated Dashboard Mode Automation helpers ─────────────────────
  // KEY DESIGN: Upwork uses FULL PAGE RELOADS between pages.
  // This means the while-loop approach BREAKS because the loop dies when the
  // page reloads. Instead we use a per-page-load approach:
  //   1. On each page load, check if a job is running
  //   2. Check which page we are on
  //   3. Scrape this page
  //   4. Navigate to next page (which triggers reload → starts over from step 1)
  //   5. If we've scraped all pages, run enrichment instead
  async function checkAutomatedMode() {
    try {
      const res = await sendToBackend('https://upwork-one-mauve.vercel.app/api/status');
      if (!res || !res.job) return;
      const job = res.job;

      if (!job || !job.running) return;

      console.log('[Upwork Scraper] Active automated job detected. Page:', getCurrentPage(), '/', job.maxPages);

      // Show automation status panel, hide manual buttons
      const actionsEl = document.querySelector('.uw-scraper-actions');
      const autoPanelEl = document.getElementById('uw-automation-panel');
      if (actionsEl) actionsEl.style.display = 'none';
      if (autoPanelEl) autoPanelEl.style.display = 'flex';

      const currentPage = getCurrentPage();
      const statusTextEl = document.getElementById('uw-auto-status-text');

      // Wait for page content to fully render before scraping
      await sleep(2000);
      await Promise.race([waitForContentUpdate(), sleep(4000)]);

      // Update status
      if (statusTextEl) {
        statusTextEl.innerHTML = `<strong>Phase:</strong> Scraping<br/><strong>Page:</strong> ${currentPage} of ${job.maxPages}<br/><strong>Collected so far:</strong> ${(job.data || []).length} profiles<br/>Scraping this page...`;
      }
      setStatus(`Automating: Scraping page ${currentPage} of ${job.maxPages}...`, 'info');

      // Restore accumulated leads from server
      scrapedData = job.data || [];

      // 1. Scrape current page
      const results = extractDataFromPage();
      const existingUrls = new Set(scrapedData.map(d => d.profileUrl));
      const newLeads = [];
      results.forEach(r => {
        if (!existingUrls.has(r.profileUrl)) {
          scrapedData.push(r);
          existingUrls.add(r.profileUrl);
          newLeads.push(r);
        }
      });
      updateUI();

      console.log(`[Upwork Scraper] Scraped ${results.length} results (${newLeads.length} new) on page ${currentPage}`);

      if (statusTextEl) {
        statusTextEl.innerHTML = `<strong>Phase:</strong> Scraping<br/><strong>Page:</strong> ${currentPage} of ${job.maxPages}<br/><strong>Collected:</strong> ${scrapedData.length} profiles<br/>Saving results...`;
      }

      // 3. Decide what to do next
      if (currentPage < job.maxPages) {
        // Update server with progress and indicate we're moving to next page
        await sendToBackend('https://upwork-one-mauve.vercel.app/api/job/update', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            phase: 'scraping',
            page: currentPage,
            total: scrapedData.length,
            data: scrapedData,
            message: `Scraped page ${currentPage} of ${job.maxPages}. Navigating to page ${currentPage + 1}...`
          })
        }).catch(err => console.warn('Job update failed:', err));

        if (statusTextEl) {
          statusTextEl.innerHTML = `<strong>Phase:</strong> Scraping<br/><strong>Page:</strong> ${currentPage} of ${job.maxPages}<br/><strong>Collected:</strong> ${scrapedData.length} profiles<br/>Navigating to page ${currentPage + 1}...`;
        }
        setStatus(`Navigating to page ${currentPage + 1}...`, 'info');

        // Wait briefly then navigate — the page reload will re-trigger checkAutomatedMode
        await sleep(1500);
        const nextUrl = buildNextPageUrl(currentPage + 1);
        console.log('[Upwork Scraper] Navigating to:', nextUrl);
        window.location.href = nextUrl;

      } else {
        // All pages scraped — update server and run enrichment
        await sendToBackend('https://upwork-one-mauve.vercel.app/api/job/update', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            phase: 'scraping',
            page: currentPage,
            total: scrapedData.length,
            data: scrapedData,
            message: `Scraped all ${job.maxPages} pages. Starting enrichment...`
          })
        }).catch(err => console.warn('Job update failed:', err));

        await runAutomatedEnrichment(job);
      }

    } catch (e) {
      console.warn('[Upwork Scraper] Failed in automated mode execution:', e);
    }
  }

  function buildNextPageUrl(pageNum) {
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('page', String(pageNum));
      return url.toString();
    } catch (_) {
      return window.location.href + (window.location.href.includes('?') ? '&' : '?') + 'page=' + pageNum;
    }
  }

  function getCurrentPage() {
    try {
      const urlParams = new URLSearchParams(window.location.search);
      return Number(urlParams.get('page') || '1');
    } catch (_) {
      return 1;
    }
  }

  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  function clickNextPageTarget() {
    const nextButton = document.querySelector(
      'button[data-test="pagination-next"], ' +
      '.up-pagination-next, ' +
      'a[data-test="pagination-next"], ' +
      'button.pagination-next, ' +
      '[aria-label="Next"]'
    );

    let nextPageLink = null;
    if (!nextButton || nextButton.disabled) {
      const pageLinks = document.querySelectorAll('.up-pagination a, [data-test="pagination"] a, nav[aria-label="Pagination"] a');
      const currentPage = document.querySelector('.up-pagination .is-active, [aria-current="page"], .pagination .active');
      if (currentPage) {
        nextPageLink = currentPage.nextElementSibling?.querySelector('a') || currentPage.nextElementSibling;
      }
    }

    const clickTarget = (nextButton && !nextButton.disabled) ? nextButton : nextPageLink;
    return clickTarget;
  }

  async function runAutomatedEnrichment(job) {
    setStatus('Scraping done. Automating enrichment...', 'info');

    const agenciesToEnrich = [];
    scrapedData.forEach((d, idx) => {
      if (d.agencyName && !d._enriched) {
        agenciesToEnrich.push({ agencyName: d.agencyName, agencyUrl: d.agencyUrl, idx });
      }
    });

    const totalAgencies = agenciesToEnrich.length;
    if (totalAgencies === 0) {
      await finishAutomatedJob(scrapedData.length);
      return;
    }

    const statusTextEl = document.getElementById('uw-auto-status-text');
    if (statusTextEl) {
      statusTextEl.innerHTML = `<strong>Phase:</strong> Enriching<br/><strong>Progress:</strong> 0 of ${totalAgencies}<br/>Starting social searches...`;
    }

    await sendToBackend('https://upwork-one-mauve.vercel.app/api/job/update', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        phase: 'enriching',
        enrichedAgencies: 0,
        totalAgencies: totalAgencies,
        message: `Found ${totalAgencies} agencies to enrich. Starting background social search...`
      })
    }).catch(err => console.warn(err));

    let enrichedCount = 0;
    for (const agency of agenciesToEnrich) {
      // Check if job stopped
      const checkRes = await sendToBackend('https://upwork-one-mauve.vercel.app/api/status').catch(() => null);
      if (checkRes && checkRes.job && !checkRes.job.running) {
        console.log('[Upwork Scraper] Job was stopped from dashboard during enrichment.');
        return;
      }

      if (statusTextEl) {
        statusTextEl.innerHTML = `<strong>Phase:</strong> Enriching<br/><strong>Progress:</strong> ${enrichedCount} of ${totalAgencies}<br/>Searching links for: ${agency.agencyName}`;
      }
      setStatus(`Automating: Enriching agency ${enrichedCount + 1}/${totalAgencies}...`, 'info');
      try {
        const result = await new Promise((resolve, reject) => {
          chrome.runtime.sendMessage(
            { action: 'enrichAgency', agencyUrl: agency.agencyUrl, agencyName: agency.agencyName },
            response => {
              if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
              } else {
                resolve(response);
              }
            }
          );
        });

        const idx = agency.idx;
        if (result && result.website) {
          scrapedData[idx].website = result.website;
          scrapedData[idx].socials = result.socials || {};
        }
        scrapedData[idx]._enriched = true;
        enrichedCount++;
        updateUI();

        await sendToBackend('https://upwork-one-mauve.vercel.app/api/job/update', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            phase: 'enriching',
            enrichedAgencies: enrichedCount,
            totalAgencies: totalAgencies,
            data: scrapedData,
            message: `Enriched agency ${enrichedCount} of ${totalAgencies}: ${agency.agencyName}.`
          })
        }).catch(err => console.warn(err));

        await sleep(1000);
      } catch (e) {
        console.warn('Enrichment error:', e);
        scrapedData[agency.idx]._enriched = true;
        enrichedCount++;
      }
    }

    await finishAutomatedJob(scrapedData.length);
  }

  async function finishAutomatedJob(totalLeads) {
    setStatus('Automated job completed successfully!', 'success');
    
    // Keep standard actions hidden, show completion status card
    const actionsEl = document.querySelector('.uw-scraper-actions');
    const autoPanelEl = document.getElementById('uw-automation-panel');
    if (actionsEl) actionsEl.style.display = 'none';
    if (autoPanelEl) autoPanelEl.style.display = 'flex';

    // Update title and status text
    const titleEl = document.getElementById('uw-auto-title');
    const statusTextEl = document.getElementById('uw-auto-status-text');
    const abortBtn = document.getElementById('uw-btn-abort-auto');
    
    if (titleEl) {
      titleEl.innerHTML = `<span style="background: #10b981; width: 7px; height: 7px; border-radius: 50%; display: inline-block;"></span> Scrape Completed`;
      titleEl.style.color = '#10b981';
    }
    
    if (statusTextEl) {
      statusTextEl.innerHTML = `Finished scraping! <strong>${totalLeads}</strong> leads have been sent and saved to your Dashboard outreach list.`;
    }
    
    if (abortBtn) {
      abortBtn.textContent = 'Close & Reset';
      abortBtn.className = 'uw-btn uw-btn-secondary';
      abortBtn.style.background = '#f1f5f9';
      abortBtn.style.color = '#475569';
      abortBtn.style.borderColor = '#e2e8f0';
    }

    // Update backend status to done
    await sendToBackend('https://upwork-one-mauve.vercel.app/api/job/update', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        running: false,
        phase: 'done',
        message: `Scraping complete. Collected ${totalLeads} profiles and enriched social links.`,
        statusType: 'success',
        data: scrapedData
      })
    }).catch(err => console.warn(err));
  }

  async function abortAutomation() {
    const abortBtn = document.getElementById('uw-btn-abort-auto');
    const isReset = abortBtn && (abortBtn.textContent.includes('Reset') || abortBtn.textContent.includes('Close'));
    
    if (isReset) {
      // Local UI reset to manual mode
      const actionsEl = document.querySelector('.uw-scraper-actions');
      const autoPanelEl = document.getElementById('uw-automation-panel');
      if (actionsEl) actionsEl.style.display = 'flex';
      if (autoPanelEl) autoPanelEl.style.display = 'none';
      
      // Reset button style
      if (abortBtn) {
        abortBtn.textContent = 'Abort Scraper';
        abortBtn.className = 'uw-btn uw-btn-danger';
        abortBtn.style.background = '';
        abortBtn.style.color = '';
        abortBtn.style.borderColor = '';
      }
      
      // Reset title styles
      const titleEl = document.getElementById('uw-auto-title');
      if (titleEl) {
        titleEl.innerHTML = `<span class="status-dot" style="background: #4f46e5; animation: pulse 1s ease-in-out infinite; width: 7px; height: 7px; border-radius: 50%;"></span> Dashboard Automation Active`;
        titleEl.style.color = '#4f46e5';
      }
      return;
    }

    setStatus('Aborting automated scraping...', 'warning');
    try {
      await sendToBackend('https://upwork-one-mauve.vercel.app/api/stop', { method: 'POST', body: '{}' });
      setStatus('Automated job aborted.', 'warning');
      
      const actionsEl = document.querySelector('.uw-scraper-actions');
      const autoPanelEl = document.getElementById('uw-automation-panel');
      if (actionsEl) actionsEl.style.display = 'flex';
      if (autoPanelEl) autoPanelEl.style.display = 'none';
    } catch (e) {
      console.warn('Failed to stop job:', e);
      setStatus('Could not abort job on dashboard.', 'error');
    }
  }

  // ── Initialize ─────────────────────────────────────────────────────
  function init() {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        setTimeout(() => {
          createFloatingPanel();
          checkAutomatedMode();
        }, 1500);
      });
    } else {
      setTimeout(() => {
        createFloatingPanel();
        checkAutomatedMode();
      }, 1500);
    }
  }

  init();
})();
