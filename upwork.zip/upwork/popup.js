// Upwork Talent Scraper - Popup Script

document.addEventListener('DOMContentLoaded', async () => {
  const statusDot = document.getElementById('statusDot');
  const statusText = document.getElementById('statusText');
  const dataCount = document.getElementById('dataCount');
  const btnOpenSearch = document.getElementById('btnOpenSearch');
  const btnExport = document.getElementById('btnExport');
  const messageEl = document.getElementById('message');

  // ── Check current tab status ───────────────────────────────────
  async function checkStatus() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      if (tab && tab.url && tab.url.includes('upwork.com/nx/search/talent')) {
        statusDot.classList.add('active');
        statusText.classList.add('active');
        statusText.textContent = 'On Upwork talent search';

        // Get data count from content script
        try {
          const response = await chrome.tabs.sendMessage(tab.id, { action: 'getStatus' });
          if (response) {
            dataCount.textContent = response.count || '0';
            btnExport.disabled = (response.count || 0) === 0;
          }
        } catch (e) {
          // Content script might not be loaded yet
          statusText.textContent = 'Page loading...';
        }
      } else {
        statusDot.classList.remove('active');
        statusText.classList.remove('active');
        statusText.textContent = 'Not on search page';
      }
    } catch (e) {
      console.error('Status check error:', e);
    }
  }

  // ── Show message ───────────────────────────────────────────────
  function showMessage(text, type = 'info') {
    messageEl.textContent = text;
    messageEl.className = `message show ${type}`;
    setTimeout(() => {
      messageEl.className = 'message';
    }, 4000);
  }

  // ── Open Upwork search ─────────────────────────────────────────
  btnOpenSearch.addEventListener('click', () => {
    const url = 'https://www.upwork.com/nx/search/talent/?loc=americas,antarctica,australia-and-new-zealand,europe&nbs=1&pt=agency';
    chrome.tabs.create({ url });
  });

  // ── Export from popup ──────────────────────────────────────────
  btnExport.addEventListener('click', async () => {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.url.includes('upwork.com')) {
        const response = await chrome.tabs.sendMessage(tab.id, { action: 'export' });
        if (response && response.success) {
          showMessage('Excel file downloaded!', 'success');
        }
      } else {
        showMessage('Please open Upwork talent search first.', 'error');
      }
    } catch (e) {
      showMessage('Error: Content script not loaded. Refresh the page.', 'error');
    }
  });

  // ── Initialize ─────────────────────────────────────────────────
  checkStatus();

  // Poll status every 2 seconds while popup is open
  setInterval(checkStatus, 2000);
});
