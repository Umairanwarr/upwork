(function () {
  const check = () => {
    window.dispatchEvent(new CustomEvent('UPWORK_SCRAPER_EXTENSION_INSTALLED'));
    document.documentElement.setAttribute('data-uw-extension-installed', 'true');
  };
  check();
  // Periodically check/dispatch in case page loaded late
  const interval = setInterval(check, 1000);
  setTimeout(() => clearInterval(interval), 5000);
})();
